import styled from "styled-components";

export const RightContentBox = styled.div`
  width: 100%;
  height: calc(100vh - 3.5rem);
  position: relative;
  padding: 2rem;
`;
